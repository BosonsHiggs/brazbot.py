"""
Voice Call Example — brazbot.py v2.0.0
======================================
Demonstrates Voice Gateway v8 connection and Opus audio streaming.
"""

import os
from typing import Optional
from brazbot import Bot, CommandContext, Intents, VoiceChannel, describe

bot = Bot(
    token=os.getenv("DISCORD_TOKEN", ""),
    command_prefix="!",
    intents=Intents.default() | Intents.MESSAGE_CONTENT | Intents.GUILD_VOICE_STATES,
)


@bot.command(name="join_call", description="Joins a voice channel with Voice Gateway v8")
@describe(channel="Voice channel to join")
async def join_call(ctx: CommandContext, channel: Optional[VoiceChannel] = None):
    await ctx.defer()
    target = channel or (ctx.author.voice.channel if ctx.author and ctx.author.voice else None)
    if not target:
        await ctx.send("Join a voice channel first or specify one!")
        return
    vc = await target.connect()
    await ctx.send(f"Joined **{target.name}** with encryption `{vc.udp.mode}`.")


if __name__ == "__main__":
    bot.run(os.environ["DISCORD_TOKEN"])
