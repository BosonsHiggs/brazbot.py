"""
Music Bot Example — brazbot.py v2.0.0
=====================================
Demonstrates Voice Gateway v8 connection and streaming via `MusicCog`.
"""

import os
from brazbot import Bot, Intents, MusicCog

bot = Bot(
    token=os.getenv("DISCORD_TOKEN", ""),
    command_prefix="!",
    intents=Intents.default() | Intents.MESSAGE_CONTENT | Intents.GUILD_VOICE_STATES,
)
bot.add_cog(MusicCog(bot))

if __name__ == "__main__":
    bot.run(os.environ["DISCORD_TOKEN"])
